package org.devisions.sb3redisom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb3RedisomApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sb3RedisomApplication.class, args);
	}

}
